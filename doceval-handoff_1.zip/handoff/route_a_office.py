# -*- coding: utf-8 -*-
"""Route A 的 Office / HTML 路线 —— 用 Docling 后端，**不装 torch**。

关键：绕开 docling.document_converter.DocumentConverter。
      它在 import 时会拉 docling_ibm_models → torch → 装完 5.2 GB（实测）。
      直接 import 具体 backend，装完只有 280 MB（实测，55 个包，无 torch）。

安装（macOS arm64 / Linux 均可）:
    pip install "docling-slim[format-docx]" openpyxl python-pptx \
                beautifulsoup4 marko lxml pypdfium2

已实测通过的格式与合并单元格保留情况:
    docx  → row_span 3 / 2 正确（OOXML 的 vMerge 是显式的）
    xlsx  → row_span 2 正确（合并区域是显式的）
    pptx  → 标题 + 项目符号正确
    html  → row_span 2 正确
不支持: 图片（jpg/png）。Docling 的图片路线要下载 OCR 模型 ——
        图片直接走公司 OCR API，不要用 Docling。
"""
from __future__ import annotations

import importlib
from pathlib import Path

from docling.datamodel.base_models import InputFormat
from docling.datamodel.document import InputDocument

from docir_pipeline import Block

# 扩展名 → (InputFormat, backend 模块, backend 类名)
BACKENDS = {
    ".docx": (InputFormat.DOCX, "docling.backend.msword_backend", "MsWordDocumentBackend"),
    ".xlsx": (InputFormat.XLSX, "docling.backend.msexcel_backend", "MsExcelDocumentBackend"),
    ".pptx": (InputFormat.PPTX, "docling.backend.mspowerpoint_backend", "MsPowerpointDocumentBackend"),
    ".html": (InputFormat.HTML, "docling.backend.html_backend", "HTMLDocumentBackend"),
    ".htm":  (InputFormat.HTML, "docling.backend.html_backend", "HTMLDocumentBackend"),
}

# DoclingDocument 的 label → DocIR 的 type
LABEL_MAP = {
    "title": "title", "section_header": "title", "text": "para",
    "paragraph": "para", "list_item": "list", "table": "table",
    "picture": "figure", "caption": "caption", "formula": "formula",
    "page_header": "header", "page_footer": "footer", "code": "code",
}


def supported(path: str) -> bool:
    return Path(path).suffix.lower() in BACKENDS


def parse_office(path: str) -> list[Block]:
    """把 Office / HTML 文件转成 DocIR block 列表。与 Route A 的 PDF 路线同一个契约。"""
    p = Path(path)
    fmt, mod, cls = BACKENDS[p.suffix.lower()]
    B = getattr(importlib.import_module(mod), cls)
    doc = B(InputDocument(path_or_stream=p, format=fmt, backend=B), p).convert()

    name = f"route_a/docling-slim:{p.suffix.lstrip('.')}"
    blocks, stack, order = [], [], 0

    for item, depth in doc.iterate_items():
        label = str(getattr(item, "label", "")).split(".")[-1].lower()
        btype = LABEL_MAP.get(label)
        if btype is None:
            continue

        bid = f"{p.stem}-b{order}"
        text = (getattr(item, "text", "") or "").strip()
        html = None
        if btype == "table" and hasattr(item, "data"):
            html = _table_html(item)          # 合并单元格必须走 html，markdown 会丢
            text = _table_text(item)

        # Office 文件没有页码/坐标 —— page 用 0，bbox 全 0，并如实标注
        b = Block(block_id=bid, type=btype, text=text, html=html,
                  level=depth if btype == "title" else None,
                  page=0, bbox=(0, 0, 0, 0), reading_order=order,
                  extractor=name)

        # 章节树：Docling 自己给的 depth 直接用
        while stack and (stack[-1].level or 0) >= depth:
            stack.pop()
        b.parent_id = stack[-1].block_id if stack else None
        if btype == "title":
            stack.append(b)

        blocks.append(b)
        order += 1
    return blocks


def _table_html(item) -> str:
    """从 DoclingDocument 的 table_cells 生成带 rowspan/colspan 的 html。
    这是整条 Office 路线最有价值的一步：export_to_markdown() 会把 span 拍平丢掉。"""
    d = item.data
    grid = [[None] * d.num_cols for _ in range(d.num_rows)]
    for c in d.table_cells:
        grid[c.start_row_offset_idx][c.start_col_offset_idx] = c
        for r in range(c.start_row_offset_idx, c.end_row_offset_idx):
            for k in range(c.start_col_offset_idx, c.end_col_offset_idx):
                if (r, k) != (c.start_row_offset_idx, c.start_col_offset_idx):
                    grid[r][k] = "SPANNED"
    out = ["<table>"]
    for row in grid:
        out.append("<tr>")
        for cell in row:
            if cell in (None, "SPANNED"):
                continue
            tag = "th" if getattr(cell, "column_header", False) else "td"
            attrs = ""
            if cell.row_span > 1:
                attrs += f' rowspan="{cell.row_span}"'
            if cell.col_span > 1:
                attrs += f' colspan="{cell.col_span}"'
            txt = " ".join(dict.fromkeys(cell.text.split("\n"))).strip()  # 合并格文本去重
            out.append(f"<{tag}{attrs}>{txt}</{tag}>")
        out.append("</tr>")
    out.append("</table>")
    return "".join(out)


def _table_text(item) -> str:
    d = item.data
    rows = [[""] * d.num_cols for _ in range(d.num_rows)]
    for c in d.table_cells:
        txt = " ".join(dict.fromkeys(c.text.split("\n"))).strip()
        for r in range(c.start_row_offset_idx, c.end_row_offset_idx):
            for k in range(c.start_col_offset_idx, c.end_col_offset_idx):
                rows[r][k] = txt
    return "\n".join(" | ".join(r) for r in rows)


if __name__ == "__main__":
    import sys
    for f in sys.argv[1:]:
        if not supported(f):
            print(f"{f}: 不支持（图片走公司 OCR API，PDF 走 Route A 的 PDF 路线）")
            continue
        bs = parse_office(f)
        print(f"\n=== {f}: {len(bs)} blocks ===")
        for b in bs[:14]:
            print(f"  [{b.reading_order:02d}] {b.type:8s} lvl={b.level} "
                  f"parent={b.parent_id} :: {b.text[:44]!r}")
        for b in bs:
            if b.type == "table":
                print("  table html:", b.html[:300])
                break
