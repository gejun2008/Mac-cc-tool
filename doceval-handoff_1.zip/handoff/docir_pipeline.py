# -*- coding: utf-8 -*-
"""
DocIR 解析流水线 —— 最小可运行骨架
=====================================
展示三路架构的"骨架"部分：Triage 分诊 → Route 适配器 → DocIR → Quality Gate。
Route A（原生结构解析）为完整实现；Route B/C 以 adapter 接口给出，
说明新增模型时只需实现同一个 parse() 契约，路由与 DocIR 不变。
"""
from __future__ import annotations

import json
import re
import statistics
from dataclasses import dataclass, field, asdict
from typing import Optional, Protocol

import pymupdf

# ==========================================================================
# 1. DocIR —— 唯一的输出契约。三路解析最终都收口到这里。
# ==========================================================================

BlockType = str  # title | para | list | table | figure | formula | caption
#                  | header | footer | stamp | signature


@dataclass
class Block:
    block_id: str
    type: BlockType
    text: str = ""
    level: Optional[int] = None          # 标题层级
    html: Optional[str] = None           # 表格结构（含 rowspan/colspan）
    latex: Optional[str] = None          # 公式
    page: int = 0
    bbox: tuple = (0, 0, 0, 0)           # 溯源坐标：回原文高亮靠它
    reading_order: int = 0
    parent_id: Optional[str] = None      # 章节树：下游重建层级靠它
    confidence: float = 1.0
    extractor: str = ""                  # 哪一路 / 哪个模型产出 —— 可归因
    lang: str = "zh"


@dataclass
class DocIR:
    doc_id: str
    source_uri: str
    meta: dict = field(default_factory=dict)
    blocks: list[Block] = field(default_factory=list)
    page_reports: list[dict] = field(default_factory=list)


# ==========================================================================
# 2. Route 适配器契约 —— 三路 = 三个 adapter，不是三套代码库
# ==========================================================================

class RouteAdapter(Protocol):
    name: str

    def parse_page(self, doc, page_no: int, profile: "PageProfile") -> list[Block]:
        ...


# ==========================================================================
# 3. Triage —— 逐页分诊（路由单位是页，不是文档）
# ==========================================================================

GARBLE = re.compile(r"[\ufffd\x00-\x08\x0b\x0c\x0e-\x1f]")


@dataclass
class PageProfile:
    page: int
    char_count: int
    garble_ratio: float
    image_area_ratio: float
    n_columns: int
    table_count: int
    route: str = "A"
    reason: str = ""


def triage_page(doc, page_no: int) -> PageProfile:
    page = doc[page_no]
    raw = page.get_text("text")
    chars = len(raw.strip())
    garble = len(GARBLE.findall(raw)) / max(chars, 1)

    img_area = sum(abs((b[2] - b[0]) * (b[3] - b[1])) for b in page.get_images(full=True)[:0]) \
        if False else sum(
            abs(r.width * r.height) for r in
            [pymupdf.Rect(i["bbox"]) for i in page.get_text("dict")["blocks"] if i["type"] == 1]
        )
    page_area = page.rect.width * page.rect.height

    tables = page.find_tables()
    prof = PageProfile(
        page=page_no + 1,
        char_count=chars,
        garble_ratio=round(garble, 4),
        image_area_ratio=round(img_area / page_area, 4),
        n_columns=_detect_columns(page)[0],
        table_count=len(tables.tables),
    )

    # ---- 路由决策：只看客观特征，不看扩展名 ----
    if chars < 60 or prof.image_area_ratio > 0.55:
        prof.route, prof.reason = "B", "无可信文本层（疑扫描页）→ 版面模型流水线"
    elif garble > 0.02:
        prof.route, prof.reason = "B", "乱码率超阈值 → 字库缺失，改走 OCR"
    else:
        prof.route, prof.reason = "A", "文本层可信 → 原生结构解析（零模型、确定性）"
    return prof


def _detect_columns(page) -> tuple[int, list[float]]:
    """按行 x0 的最大间隙做栏切分。返回 (栏数, 各栏左边界)。"""
    xs = sorted({round(l["bbox"][0]) for b in page.get_text("dict")["blocks"]
                 if b["type"] == 0 for l in b["lines"]})
    if len(xs) < 2:
        return 1, xs
    gaps = [(xs[i + 1] - xs[i], xs[i + 1]) for i in range(len(xs) - 1)]
    gap, edge = max(gaps)
    if gap > page.rect.width * 0.18:          # 存在明显竖向留白 → 多栏
        return 2, [xs[0], edge]
    return 1, [xs[0]]


# ==========================================================================
# 4. Route A —— 原生结构解析（完整实现）
# ==========================================================================

NUM_HEAD = re.compile(r"^(\d+(?:\.\d+)*)[.、\s]\s*\S")
CAPTION = re.compile(r"^(表|图|Table|Figure)\s*\d+")
MATHY = re.compile(r"[=≤≥±×÷∑∫√]|\b[a-zA-Z]\s*/\s*[a-zA-Z]\b")


class RouteANative:
    name = "route_a/native+geometry"

    def parse_page(self, doc, page_no, profile, lines=None):
        """lines 为 None 时用 PyMuPDF 取文本行；传入时用外部来源（见 RouteADocling）。"""
        page = doc[page_no]
        H = page.rect.height
        ncol, edges = _detect_columns(page)

        tables = list(page.find_tables().tables)
        table_rects = [pymupdf.Rect(t.bbox) for t in tables]
        fig_rects = _figure_rects(page, table_rects)

        if lines is None:
            lines = []
            for b in page.get_text("dict")["blocks"]:
                if b["type"] != 0:
                    continue
                for l in b["lines"]:
                    txt = "".join(s["text"] for s in l["spans"]).strip()
                    if not txt:
                        continue
                    lines.append({
                        "text": txt, "bbox": tuple(round(v, 1) for v in l["bbox"]),
                        "size": max(s["size"] for s in l["spans"]),
                    })
        # 表格内文字交给表格识别、图内文字归图，避免重复与串段
        lines = [l for l in lines
                 if not any(pymupdf.Rect(l["bbox"]).intersects(r)
                            for r in table_rects + fig_rects)]

        lines = _dedup_fake_bold(lines)           # 伪加粗=同一行画两遍 → 去重

        # 悬挂缩进标题在 PDF 里是两条独立的行（"3.1" 和标题文字分开），
        # 不先合并的话编号会被单独判成 title —— 101 页实测里这是最大的误判来源。
        def _col(l):
            if ncol == 1:
                return 0
            return 0 if l["bbox"][0] < edges[1] - 5 else 1
        lines = _merge_same_row(lines, _col)
        body_size = statistics.median([l["size"] for l in lines]) if lines else 9.0

        blocks, order = [], 0

        # --- 4.1 页眉页脚：按位置带 + 版式特征识别，分类保留而非删除 ---
        content = []
        for l in lines:
            y0 = l["bbox"][1]
            if y0 < H * 0.05:
                blocks.append(self._mk(f"p{profile.page}-hdr", "header", l, profile, order))
                order += 1
            elif l["bbox"][3] > H * 0.955:
                blocks.append(self._mk(f"p{profile.page}-ftr", "footer", l, profile, order))
                order += 1
            else:
                content.append(l)

        # --- 4.2 图题/表题单独成类，稍后与对象绑定 ---
        caps = [l for l in content if CAPTION.match(l["text"])]
        content = [l for l in content if l not in caps]

        # --- 4.3 阅读顺序：栏内自上而下，栏间从左到右 ---
        def col_of(l):
            if ncol == 1:
                return 0
            return 0 if l["bbox"][0] < edges[1] - 5 else 1

        # --- 4.3b 行内标题（"4.3 记录与归档：xxx"）拆成 title + para ---
        expanded = []
        for l in content:
            m = NUM_HEAD.match(l["text"])
            if m and "：" in l["text"][:16]:
                i = l["text"].index("：")
                expanded.append({**l, "text": l["text"][:i], "_force": "title",
                                 "_lvl": m.group(1).count(".") + 1})
                if l["text"][i + 1:]:
                    expanded.append({**l, "text": l["text"][i + 1:]})
            else:
                expanded.append(l)
        content = expanded

        content.sort(key=lambda l: (col_of(l), l["bbox"][1]))   # 栏内自上而下

        # --- 4.4 分类 + 同类相邻行合并成段 ---
        cur = None
        for l in content:
            kind, lvl = self._classify(l, body_size, edges, col_of(l))
            if cur and cur["kind"] == kind == "para":
                cur["text"] += l["text"]
                cur["bbox"] = _union(cur["bbox"], l["bbox"])
                continue
            if cur:
                blocks.append(self._emit(cur, profile, order)); order += 1
            cur = {"kind": kind, "level": lvl, "text": l["text"], "bbox": l["bbox"]}
        if cur:
            blocks.append(self._emit(cur, profile, order)); order += 1

        # --- 4.5 表格：结构识别 + 合并单元格向下填充 ---
        for i, t in enumerate(tables):
            grid = t.extract()
            grid = _fill_merged(grid)
            blocks.append(Block(
                block_id=f"p{profile.page}-tbl{i}", type="table",
                text=_grid_to_text(grid), html=_grid_to_html(grid),
                page=profile.page, bbox=tuple(round(v, 1) for v in t.bbox),
                reading_order=order, extractor=self.name,
                confidence=0.95,
            ))
            order += 1

        # --- 4.5b 图区：矢量框/位图区域单独成 block，内容留图不留字 ---
        for k, r in enumerate(fig_rects):
            blocks.append(Block(
                block_id=f"p{profile.page}-fig{k}", type="figure",
                text="[figure]", page=profile.page,
                bbox=tuple(round(v, 1) for v in r), reading_order=order,
                extractor=self.name, confidence=0.8))
            order += 1

        # --- 4.6 图题绑定到最近的表格/图 ---
        for j, c in enumerate(caps):
            blocks.append(Block(
                block_id=f"p{profile.page}-cap{j}", type="caption", text=c["text"],
                page=profile.page, bbox=c["bbox"], reading_order=order,
                extractor=self.name))
            order += 1
        return blocks

    # ---- 分类规则 ----
    def _classify(self, l, body_size, edges, col):
        t = l["text"]
        if l.get("_force") == "title":
            return "title", l.get("_lvl", 2)
        if NUM_HEAD.match(t) and l["size"] >= body_size - 0.2 and len(t) < 30:
            lvl = NUM_HEAD.match(t).group(1).count(".") + 1
            return "title", lvl
        # 缩进 + 数学符号 → 独立公式行；但连续三个英文词说明这是散文（101 页实测抓出的 bug）
        if (MATHY.search(t) and l["bbox"][0] > edges[col] + 8
                and not re.search(r"[A-Za-z]{3,}\s+[A-Za-z]{3,}\s+[A-Za-z]{3,}", t)):
            return "formula", None
        return "para", None

    def _emit(self, cur, profile, order):
        bid = f"p{profile.page}-b{order}"
        if cur["kind"] == "formula":
            return Block(bid, "formula", text=cur["text"], latex=_to_latex(cur["text"]),
                         page=profile.page, bbox=cur["bbox"], reading_order=order,
                         extractor=self.name, confidence=0.6)
        return Block(bid, cur["kind"], text=cur["text"], level=cur["level"],
                     page=profile.page, bbox=cur["bbox"], reading_order=order,
                     extractor=self.name)

    def _mk(self, bid, kind, l, profile, order):
        return Block(f"{bid}-{order}", kind, text=l["text"], page=profile.page,
                     bbox=l["bbox"], reading_order=order, extractor=self.name)


# ==========================================================================
# 5. Route B / C —— adapter 接口（本 demo 无 GPU，给出契约与触发条件）
# ==========================================================================

class RouteBLayoutModel:
    """MinerU / Marker2+Surya / PP-StructureV3 挂在这里。
    版面检测 → 阅读顺序 → 分区域识别（文本/表格/公式），输出天然带 bbox。"""
    name = "route_b/layout-pipeline"

    def parse_page(self, doc, page_no, profile):
        raise NotImplementedError("需 GPU 推理服务；本 demo 仅演示路由与闸门决策")


class RouteCVLM:
    """端到端 VLM。只在页级触发，且必须做坐标回锚以检测幻觉。"""
    name = "route_c/vlm"

    def parse_page(self, doc, page_no, profile, cross_page_context=None):
        raise NotImplementedError("走外部多模态 API；本 demo 用离线样例代入")

    @staticmethod
    def anchor_back(vlm_text: str, ocr_lines: list[dict]) -> float:
        """把 VLM 文本回锚到 OCR 行坐标：锚不上的即为模型编造。
        返回可锚定字符占比 —— 这就是幻觉率的倒数。"""
        pool = "".join(l["text"] for l in ocr_lines)
        hit = sum(1 for ch in vlm_text if ch in pool)
        return hit / max(len(vlm_text), 1)


# ==========================================================================
# 6. 后处理算子（跨页缝合 + 章节树）
# ==========================================================================

def stitch_cross_page_tables(ir: DocIR) -> list[str]:
    """续表识别：列数相同、列边界对齐、后表无表头 → 合并并沿用前表表头。"""
    logs = []
    tables = [b for b in ir.blocks if b.type == "table"]
    for prev, nxt in zip(tables, tables[1:]):
        if nxt.page != prev.page + 1:
            continue
        pg, ng = _html_to_grid(prev.html), _html_to_grid(nxt.html)
        if not pg or not ng or len(pg[0]) != len(ng[0]):
            continue
        if _looks_like_header(ng[0]) or not _x_aligned(prev.bbox, nxt.bbox):
            continue
        merged = pg + _fill_merged([pg[0]] + ng)[1:]     # 表头注入后再填充合并单元格
        prev.html = _grid_to_html(merged)
        prev.text = _grid_to_text(merged)
        prev.confidence = min(prev.confidence, 0.9)
        nxt.type = "_merged_into_" + prev.block_id
        logs.append(f"缝合 {nxt.block_id} → {prev.block_id}（续表无表头，已注入 p{prev.page} 表头）")
    ir.blocks = [b for b in ir.blocks if not b.type.startswith("_merged_into_")]
    return logs


def build_section_tree(ir: DocIR):
    """用标题层级回填 parent_id —— 结构信息只能在解析阶段产出，下游补不回来。"""
    stack: list[Block] = []
    for b in sorted(ir.blocks, key=lambda x: (x.page, x.reading_order)):
        if b.type in ("header", "footer"):
            continue
        if b.type == "title":
            while stack and (stack[-1].level or 0) >= (b.level or 1):
                stack.pop()
            b.parent_id = stack[-1].block_id if stack else None
            stack.append(b)
        else:
            b.parent_id = stack[-1].block_id if stack else None


# ==========================================================================
# 7. Quality Gate —— A→B→C 升级的唯一依据
# ==========================================================================

THRESHOLDS = {
    "char_coverage_min": 0.97,
    "garble_max": 0.02,
    "line_recall_min": 0.98,
    "table_valid_min": 1.0,
    "order_jump_max": 3,
}


def gate_page(doc, page_no, blocks, profile) -> dict:
    """字符覆盖率用文本层做免费 ground truth —— 这是 Route A 独有的优势。
    行覆盖率抓的是"整块内容静默丢失"，是版面类错误最灵敏的探针。"""
    page = doc[page_no]
    layer_lines = _layer_lines(page)
    layer = re.sub(r"\s+", "", "".join(l["text"] for l in layer_lines))
    got = re.sub(r"\s+", "", "".join(b.text for b in blocks))

    cov = len(got) / max(len(layer), 1)
    garble = len(GARBLE.findall(got)) / max(len(got), 1)

    # 行覆盖率：每条文本层行的中心点是否落在某个 block 框内
    covered = 0
    for l in layer_lines:
        cx = (l["bbox"][0] + l["bbox"][2]) / 2
        cy = (l["bbox"][1] + l["bbox"][3]) / 2
        if any(b.bbox[0] - 2 <= cx <= b.bbox[2] + 2 and
               b.bbox[1] - 2 <= cy <= b.bbox[3] + 2 for b in blocks):
            covered += 1
    line_recall = covered / max(len(layer_lines), 1)

    tbl = [b for b in blocks if b.type == "table"]
    valid = 1.0
    for t in tbl:
        g = _html_to_grid(t.html)
        if g and len({len(r) for r in g}) != 1:
            valid = 0.0

    seq = [b for b in sorted(blocks, key=lambda x: x.reading_order)
           if b.type not in ("header", "footer")]
    # 向上倒退且未换栏 → 阅读顺序异常（换栏引起的回到页顶是正常的）
    jumps = sum(1 for a, b in zip(seq, seq[1:])
                if b.bbox[1] < a.bbox[1] - 60 and b.bbox[0] < a.bbox[0] + 40)

    m = {
        "page": profile.page,
        "route": profile.route,
        "char_coverage": round(min(cov, 1.0), 4),
        "garble_ratio": round(garble, 4),
        "line_recall": round(line_recall, 4),
        "table_validity": valid,
        "order_jumps": jumps,
    }
    fails = []
    if m["char_coverage"] < THRESHOLDS["char_coverage_min"]:
        fails.append("字符覆盖率不足（疑漏块）")
    if m["garble_ratio"] > THRESHOLDS["garble_max"]:
        fails.append("乱码率超阈值")
    if m["line_recall"] < THRESHOLDS["line_recall_min"]:
        fails.append("行覆盖率不足（疑版面漏检）")
    if m["table_validity"] < THRESHOLDS["table_valid_min"]:
        fails.append("表格行列不一致")
    if m["order_jumps"] > THRESHOLDS["order_jump_max"]:
        fails.append("阅读顺序几何跳变异常")

    m["failures"] = fails
    m["decision"] = "PASS" if not fails else (
        "ESCALATE→B" if profile.route == "A" else
        "ESCALATE→C" if profile.route == "B" else "NEEDS_HUMAN")
    return m


# ==========================================================================
# 8. 渲染器：markdown 只是 DocIR 的一个视图，不是解析产物本身
# ==========================================================================

def render_markdown(ir: DocIR, keep_furniture=False) -> str:
    out = []
    for b in sorted(ir.blocks, key=lambda x: (x.page, x.reading_order)):
        if b.type in ("header", "footer") and not keep_furniture:
            continue
        if b.type == "title":
            out.append("#" * min(b.level or 1, 6) + " " + b.text)
        elif b.type == "formula":
            out.append(f"$$\n{b.latex}\n$$")
        elif b.type == "table":
            out.append(b.html)
        elif b.type == "caption":
            out.append(f"*{b.text}*")
        elif b.type in ("header", "footer"):
            out.append(f"<!-- {b.type}: {b.text} -->")
        else:
            out.append(b.text)
    return "\n\n".join(out)


# ==========================================================================
# 工具函数
# ==========================================================================

def _union(a, b):
    return (min(a[0], b[0]), min(a[1], b[1]), max(a[2], b[2]), max(a[3], b[3]))


def _merge_same_row(lines, col_of, max_gap=40, y_tol=2.5):
    """把同一栏、同一基线、水平间隔很小的行合并成一行。"""
    lines = sorted(lines, key=lambda l: (col_of(l), round(l["bbox"][1] / 2), l["bbox"][0]))
    out = []
    for l in lines:
        if out:
            p = out[-1]
            same_row = (col_of(l) == col_of(p)
                        and abs(l["bbox"][1] - p["bbox"][1]) < y_tol
                        and abs(l["bbox"][3] - p["bbox"][3]) < y_tol)
            gap = l["bbox"][0] - p["bbox"][2]
            if same_row and -1 <= gap <= max_gap:
                p["text"] = (p["text"] + " " + l["text"]).strip()
                p["bbox"] = _union(p["bbox"], l["bbox"])
                p["size"] = max(p["size"], l["size"])
                continue
        out.append(dict(l))
    return out


def _layer_lines(page):
    """文本层的行（已去伪加粗重复），作为解析质量的 ground truth。"""
    ls = []
    for b in page.get_text("dict")["blocks"]:
        if b["type"] != 0:
            continue
        for l in b["lines"]:
            t = "".join(s["text"] for s in l["spans"]).strip()
            if t:
                ls.append({"text": t, "bbox": tuple(round(v, 1) for v in l["bbox"])})
    return _dedup_fake_bold(ls)


def _figure_rects(page, table_rects, min_w=70, min_h=35):
    """矢量图框 / 位图区域 —— 排除表格线框。"""
    out = []
    for d in page.get_drawings():
        r = pymupdf.Rect(d["rect"])
        if r.width < min_w or r.height < min_h:
            continue
        if any(r.intersects(tr) for tr in table_rects):
            continue
        if any(r.intersects(o) for o in out):
            continue
        out.append(r)
    for i in page.get_text("dict")["blocks"]:
        if i["type"] == 1:
            out.append(pymupdf.Rect(i["bbox"]))
    return out


def _dedup_fake_bold(lines, tol=1.2):
    out = []
    for l in lines:
        dup = any(l["text"] == o["text"] and abs(l["bbox"][0] - o["bbox"][0]) < tol
                  and abs(l["bbox"][1] - o["bbox"][1]) < tol for o in out)
        if not dup:
            out.append(l)
    return out


def _fill_merged(grid):
    """合并单元格在提取结果里表现为空串 —— 按列向下继承前值。"""
    out, prev = [], None
    for row in grid:
        row = list(row)
        if prev:
            for i, c in enumerate(row):
                if (c is None or str(c).strip() == "") and i == 0:
                    row[i] = prev[i]
        out.append([("" if c is None else str(c).strip()) for c in row])
        prev = out[-1]
    return out


def _grid_to_html(grid):
    if not grid:
        return ""
    h = ["<table>"]
    for i, row in enumerate(grid):
        tag = "th" if i == 0 else "td"
        h.append("<tr>" + "".join(f"<{tag}>{c}</{tag}>" for c in row) + "</tr>")
    h.append("</table>")
    return "".join(h)


def _grid_to_text(grid):
    return "\n".join(" | ".join(r) for r in grid)


def _html_to_grid(html):
    if not html:
        return []
    rows = re.findall(r"<tr>(.*?)</tr>", html, re.S)
    return [re.findall(r"<t[hd]>(.*?)</t[hd]>", r, re.S) for r in rows]


def _looks_like_header(row):
    return all(c and not re.search(r"\d", c) for c in row) and len(set(row)) == len(row)


def _x_aligned(b1, b2, tol=6):
    return abs(b1[0] - b2[0]) < tol and abs(b1[2] - b2[2]) < tol


def _to_latex(s):
    s = s.replace("×", r"\times").replace("≤", r"\leq").replace("≥", r"\geq")
    s = re.sub(r"\(\s*([a-zA-Z])\s*/\s*([a-zA-Zx̄]+)\s*\)", r"\\frac{\1}{\2}", s)
    return s.replace("%", r"\%")


# ==========================================================================
# 主流程
# ==========================================================================

def parse(path: str) -> tuple[DocIR, list[str]]:
    doc = pymupdf.open(path)
    ir = DocIR(doc_id="SOP-QA-0417", source_uri=path)
    adapters = {"A": RouteANative(), "B": RouteBLayoutModel(), "C": RouteCVLM()}

    for pno in range(doc.page_count):
        prof = triage_page(doc, pno)
        blocks = adapters[prof.route].parse_page(doc, pno, prof)
        ir.blocks.extend(blocks)
        report = gate_page(doc, pno, blocks, prof)
        report["triage_reason"] = prof.reason
        report["n_columns"] = prof.n_columns
        ir.page_reports.append(report)

    logs = stitch_cross_page_tables(ir)
    for i, b in enumerate(sorted(ir.blocks, key=lambda x: (x.page, x.reading_order))):
        b.reading_order = i                      # 缝合后重排全局阅读序
    build_section_tree(ir)

    # 文档级元数据从 header block 里抽（合规场景必需）
    hdr = next((b.text for b in ir.blocks if b.type == "header"), "")
    for k, pat in [("doc_no", r"([A-Z]+-[A-Z]+-\d+)"), ("version", r"版本[：:]\s*([\d.]+)"),
                   ("effective_date", r"生效日期[：:]\s*([\d-]+)")]:
        m = re.search(pat, hdr)
        if m:
            ir.meta[k] = m.group(1)
    return ir, logs


if __name__ == "__main__":
    ir, logs = parse("/home/claude/demo/sop_hard.pdf")
    print("== meta ==", json.dumps(ir.meta, ensure_ascii=False))
    for l in logs:
        print("== stitch ==", l)
    for r in ir.page_reports:
        print("== gate ==", json.dumps(r, ensure_ascii=False))
    print("== blocks ==", len(ir.blocks))
    for b in sorted(ir.blocks, key=lambda x: (x.page, x.reading_order)):
        print(f"  [{b.page}/{b.reading_order:02d}] {b.type:8s} lvl={b.level} "
              f"parent={b.parent_id} :: {b.text[:38]!r}")
    with open("/home/claude/demo/docir.json", "w") as f:
        json.dump({"meta": ir.meta, "page_reports": ir.page_reports,
                   "blocks": [asdict(b) for b in ir.blocks]}, f,
                  ensure_ascii=False, indent=2)
    with open("/home/claude/demo/docir.md", "w") as f:
        f.write(render_markdown(ir))
