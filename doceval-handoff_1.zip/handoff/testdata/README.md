# 测试数据三档

## arxiv/ —— 档一：回归基线（已包含，101 页）
1512.03385v1.pdf  ResNet      12 页  两栏 + 有线框表
2312.00752v2.pdf  Mamba       36 页  大量无边框表格 ← 主要压力源
2412.19437v2.pdf  DeepSeek-V3 53 页  目录页 + 附录表 + 流程图

改任何代码后：python run_eval.py testdata/arxiv
判定分布必须不差于 baseline_arxiv101.json，否则不要合并。

## internal/ —— 档二：你们的真实文档（**必须补，20-30 份**）
arXiv 全是电子版 PDF，一页扫描件都没有。按类型分层抽：
  scanned/      扫描件、影印 PDF          6-8 份  ← Route A 对它零能力
  stamped/      盖章、手写签批页          3-5 份  ← VLM 唯一无可替代的场景
  epdf/         电子 PDF（含跨页表）      5 份
  office/       docx / xlsx / pptx        5 份
  web/          网页、邮件导出            2-3 份

## golden/ —— 档三：金标集（**必须人工标，30-50 页**）
从 internal/ 抽页人工标注，每页记录：
  - 每个 block 的正确 type 和 level
  - 表格的正确行列数与合并关系（用于算 TEDS）
  - 正确的阅读顺序

格式建议（每页一个 json）：
  {"file":"xxx.pdf","page":3,"blocks":[{"type":"title","level":2,"text":"...","bbox":[...]}],
   "tables":[{"rows":7,"cols":4,"merges":[[1,0,3,1]]}],"reading_order":["b1","b2",...]}

没有这一档，所有"误判率"都只是启发式估计，无法比较任何两个模型的优劣。
