# 交接规格书 — 文档解析流水线内网落地

> 这份文件同时是给编码模型（Copilot / GPT-5.6）的任务规格。
> 读完直接开工，**不要重新设计架构**。架构已经用 101 页真实文档验证过一轮了。

---

## 0. 一句话目标

把「每种文档类型一套 loader」换成「**一个输出契约（DocIR）+ 一个原生解析器 + 三个 API adapter + 一个质量闸门**」，
下游调用签名保持不变。

**范围只有解析。** 切分、embedding、索引、检索、rerank 全部不在范围内，不要写这些代码。

---

## 1. 必须迁到内网的东西（就这 6 个文件）

| 文件 | 作用 | 状态 |
|---|---|---|
| `docir_pipeline.py` | DocIR schema + Route A 原生解析 + 后处理 + markdown renderer | **可直接跑**，已修 2 个 bug |
| `gate.py` | 质量闸门 v2：3 个指标 + 分类断言 + 升级路由 | **可直接跑** |
| `adapters.py` | 表格 / OCR / VLM 三个 API adapter | **契约已定，待实现** ← 主要工作量 |
| `config.example.yaml` | 全部参数（阈值、endpoint、熔断、环境变量清单） | 复制成 `config.yaml` 后填 |
| `baseline_arxiv101.json` | 101 页回归基线，改代码后必须比对 | 只读 |
| `route_a_office.py` | **Office / HTML 路线**：docx / xlsx / pptx / html → DocIR，合并单元格转 `rowspan/colspan` | **可直接跑**，实测通过 |
| `route_a_docling.py` | Docling 后端的 PDF Route A（可选，示范"换后端不动路由"） | 可选，可删 |

**不要迁**：`make_pdf.py` / `make_docx.py`（合成 demo 用）、`build_report.py`、`report.tpl.html`、`run_arxiv.py`（本地跑分脚本，用 `run_eval.py` 替代）。

依赖分两组，**全程不需要 torch，不需要下载任何模型权重**：

- **PDF 路线 + 闸门**：`pymupdf` + `pyyaml`，约 60 MB。
- **Office / HTML 路线**：约 280 MB（实测 55 个包，无 torch）。安装命令：
  ```
  pip install "docling-slim[format-docx]" openpyxl python-pptx beautifulsoup4 marko lxml pypdfium2
  ```

★ **绝对不要装 `docling`（不带 `-slim`），也不要 import `DocumentConverter`。**
两者都会拉 `docling_ibm_models` → torch，实测装完 **5.2 GB**。
`route_a_office.py` 的做法是直接 import 具体 backend 类，绕开那条依赖链 —— 照抄即可。

**图片（jpg/png）不要交给 Docling**，它的图片路线要从 HuggingFace 下载 OCR 模型。
图片直接走公司 OCR API（`adapters.OcrApiAdapter`）。

---

## 2. 必须一起迁的测试数据

分三档，缺任何一档这套东西都无法验收。

### 档一：回归基线（已有，直接用）
5 篇 arXiv 论文里的 3 篇，101 页。放进 `testdata/arxiv/`：
- `1512.03385v1.pdf`（ResNet，12 页，两栏 + 有线框表）
- `2312.00752v2.pdf`（Mamba，36 页，**大量无边框表格** ← 主要压力源）
- `2412.19437v2.pdf`（DeepSeek-V3，53 页，目录页 + 附录表 + 流程图）

作用：改任何代码后跑 `run_eval.py`，判定分布必须与 `baseline_arxiv101.json` 一致或更好。

### 档二：你们自己的真实文档（**必须补，这是最重要的一档**）
arXiv 全是电子版 PDF，**一页扫描件都没有**。按类型分层抽 **20–30 份**：

| 类别 | 份数建议 | 为什么必须有 |
|---|---|---|
| 扫描件 / 影印 PDF | 6–8 | 完全没测过，Route A 对它零能力 |
| 盖章 / 手写签批页 | 3–5 | 合规场景必测，且是 VLM 唯一无可替代的场景 |
| 电子 PDF（含跨页表） | 5 | 验证跨页缝合 |
| docx / xlsx / pptx | 5 | 验证 Docling 路线（零模型） |
| 网页 / 邮件导出 | 2–3 | 验证 HTML 路线 |
| 图片（jpg / png 单页扫描） | 3–5 | 只能走 OCR API，Docling 不参与 |

### 档三：金标集（**必须人工标，没有它无法比较模型**）
从档二里抽 **30–50 页**人工标注，每页记：
- 每个 block 的正确 `type` 和 `level`
- 表格的正确行列数与合并关系
- 正确阅读顺序

**这是整个项目的前提条件。** 现在报告里所有"误判率"都是我用启发式断言估的（"纯数字 = 错"），
不是 ground truth。没有金标集，你换 OCR A 还是 OCR B，没有任何依据判断谁更好。

---

## 3. 内网跑起来要设的参数

全部集中在 `config.example.yaml`，这里只列**必填**和**容易漏**的。

### 必填
```
apis.table.endpoint / apis.ocr.endpoint / apis.vlm.endpoint
apis.*.api_key_env                      # 从环境变量读，不要写进文件
apis.vlm.model_version_pin              # 写死版本，否则解析结果随模型漂移
apis.vlm.temperature = 0                # 非 0 则解析不可复现，合规不通过
```

### 环境变量（不在 yaml 里）
```
HTTP_PROXY / HTTPS_PROXY / NO_PROXY     内网代理
REQUESTS_CA_BUNDLE                      企业 CA 证书
PIP_INDEX_URL                           内网 pypi 镜像
TABLE_API_KEY / OCR_API_KEY / VLM_API_KEY
```

### 只有决定用 Docling 的 PDF 模型时才需要
```
DOCLING_ARTIFACTS_PATH                  预下载的模型目录（先跑 docling models download）
HF_HUB_OFFLINE=1                        禁止运行时访问 HuggingFace
```
**建议先不要用。** Docling 的 Office/HTML/CSV 路线零模型、零权重下载、不需要 torch，
那部分白拿；PDF 的版面能力用公司自己的 OCR / 表格 API 更省事，也不用维护模型分发。

### 三个容易漏但很重要的
```
parse.keep_figure_text: true            # ★ 零成本修复，OCR 调用从 9% 降到约 1%
budget.max_escalation_hops: 2           # 禁止无限升级
budget.vlm_page_ratio_max: 0.03         # VLM 占比熔断，防预算烧穿
```

---

## 4. 编码任务清单（按优先级，不要跳）

### P0 — 零 API 成本，先做
1. **实现 `parse.keep_figure_text`**：`docir_pipeline._figure_rects` 现在把图区内的文字整块丢弃，
   导致字符覆盖率下降、9% 的页被误判为需要 OCR。改成：图区内文字不丢弃，作为该 `figure` block
   的附属文本保留（新增字段 `figure_text`，不要新增 block）。
   **验收**：`run_eval.py` 跑 101 页，`OCR_PAGE` 从 9 页降到 ≤ 2 页，其他判定不变差。

2. **把所有硬编码阈值改成读 `config.yaml`**。`gate.py` 的 `TH` 和 `docir_pipeline` 的魔法数字全部外置。

3. **写 `run_eval.py`**：输入一个目录，输出判定分布 + 与 `baseline_arxiv101.json` 的 diff。
   任何代码改动都必须先过这个脚本。

### P1 — 接 API
4. **实现 `TableApiAdapter`**（预算 10%，收益最大）。硬要求：合并单元格必须映射成 html 的
   `rowspan/colspan`；`ctx.hint.prev_page_table_header` 存在时拼作表头。
5. **实现 `OcrApiAdapter`**（预算 9%→1%）。硬要求：每个 block 必须带换算回 PDF 点坐标的 bbox；
   OCR 结果只补缺失区域，**不要覆盖已有的可信文本层**。
6. **实现 `VlmApiAdapter`**（预算 ≤ 3%）。硬要求两条，不做不许上线：
   - `temperature=0` 且把 model 版本写进 `Block.extractor`
   - **坐标回锚**：返回文本逐段回锚到文本层 / OCR 行，锚不上的判为幻觉 → 丢弃并把该页标
     `needs_human`；回锚率写进 `Block.confidence`，< 0.95 视为超标

### P2 — 兼容与收口
7. **写 `shim.py`**：`load(file) -> markdown`，签名与现有 loader 完全一致，内部是
   `render_markdown(parse(file))`。**下游一行都不许改**，一个文件类型一个文件类型灰度切。
8. `needs_human` 队列：一张表 + 一个列表接口即可，不要做后台系统。

---

## 5. 验收标准

| 项 | 门槛 |
|---|---|
| 101 页回归 | 判定分布不差于 `baseline_arxiv101.json`；`OCR_PAGE` ≤ 2 |
| 成本 | `VLM_PAGE` 占比 ≤ 3%；升级跳数 ≤ 2 |
| 延迟 | 闸门 ≤ 10 ms/页（当前实测 4.6–7.6 ms）；Route A ≤ 600 ms/页 |
| 溯源 | 100% 的 block 带 `page` + `bbox` + `extractor` + 版本 |
| 幻觉 | VLM 产出的 block 回锚率 ≥ 0.95，否则该页进 `needs_human` |
| 兼容 | `shim.load()` 签名与旧 loader 一致，下游零改动 |
| 金标集 | 30–50 页人工标注完成，并给出 type/level 准确率与表格 TEDS 的首个基线数字 |

---

## 6. 明确不要做的事（防膨胀）

- ❌ 不要自建 GPU 版面模型流水线（MinerU / Marker）。公司有 API，先用 API。等 API 账单真的疼了再谈降本。
- ❌ 不要写新的规则算子。**101 页实测里跨页缝合触发 0 次**，规则堆砌是这类项目变垃圾的第一条路径。
  遇到解析不准 → 交给闸门 → 交给 API，不要加 if。
- ❌ 不要给 DocIR 加字段。现在 10 个（`block_id/type/level/text/html/page/bbox/reading_order/parent_id/extractor`），
  **超过 12 个就是在往契约里塞下游需求**。
- ❌ 不要做切分、索引、检索、embedding。
- ❌ 不要在闸门里加第 4 个指标，除非它能在 101 页基线上抓到现在抓不到的错。

三个膨胀警报，任何人都可以拿它否掉需求：
**后处理算子 > 3 个** ｜ **DocIR 字段 > 12 个** ｜ **adapter > 4 个**

---

## 7. 已知问题与坑（省你们踩一遍）

1. **`find_tables()` 对无边框表格完全无效。** Mamba 第 12 页整页无框结果表，检出 0 个表，
   308 行文本全流进正文通道，表格里的数字被当成编号标题。这就是要接表格 API 的原因。
2. **闸门的同源盲区。** 字符覆盖率用 PDF 文本层做 ground truth，所以**发现不了该 extractor
   自身的字符损失** —— 实测 PyMuPDF 把页脚的间隔号「·」丢了，`char_coverage` 仍是 1.00。
   要抓这类问题只能跨 extractor diff。**先只在金标集上离线跑，不要上线双跑。**
3. **换 extractor 会改变结果。** 同一份论文，PyMuPDF 与 docling-parse 的 block 数差 +6% ~ +44%
   （切行粒度不同）。所以 `extractor` 必须记进 block 并锁版本。
4. **目录页和新开章页的标题占比天然很高**，`title_ratio_max` 设 0.15 会大量误报（DeepSeek-V3
   第 2 页是 Contents）。已调到 0.30 且要求点线检测排除目录页。
5. **悬挂缩进标题在 PDF 里是两条独立的行**（"3.1" 和标题文字分开），不先合并会把编号单独判成标题。
   已修，`merge_same_row_max_gap_pt=40`。合并必须限制在同一栏内，否则两栏会被横向粘起来。
6. **arXiv 是电子版，不代表你们的文档。** 79% PASS 率不能拿去预估真实 API 预算，必须用档二数据重测。

---

## 8. 当前实测基线（用来对比，不是用来炫耀）

101 页 arXiv，Route A + 闸门 v2，第一跳预算：

```
PASS                 80  (79%)   零 API 调用
PASS_WITH_WARNING     1  ( 1%)   孤证，只记录
→ 表格 API（区域级）  10  (10%)   最便宜
→ OCR（整页）          9  ( 9%)   改 keep_figure_text 后应降到 ~1%
→ VLM（整页）          1  ( 1%)   最贵
闸门开销 4.6–7.6 ms/页；Route A 250–545 ms/页
```

分类质量（启发式估计，非人工标注）：title 误判率 41%，formula 误判率 0%，
剩余误判集中在无边框表格页 —— 那正是应该交给表格 API 的部分。
