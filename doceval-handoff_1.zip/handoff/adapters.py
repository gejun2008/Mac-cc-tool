# -*- coding: utf-8 -*-
"""待实现：三个公司内部 API 的 adapter。
契约已经定死，实现只需填 _call() 里的 HTTP 调用和响应映射。

规则：adapter 只做「输入页/区域 → 输出 list[Block]」。
不要在 adapter 里做路由判断、不要在 adapter 里改 DocIR schema。
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Optional

from docir_pipeline import Block


# ==========================================================================
# 通用请求上下文
# ==========================================================================

@dataclass
class PageCtx:
    doc_path: str
    page_no: int                      # 0-based
    page_image_png: bytes             # 已按 config.render.dpi 渲染好的整页图
    page_width: float                 # PDF 点单位，用于把 API 返回的坐标映射回 bbox
    page_height: float
    region: Optional[tuple] = None     # (x0,y0,x1,y1)，仅区域级调用时给
    hint: Optional[dict] = None        # 例如 {"prev_page_table_header": [...]}


class BaseAdapter:
    name = "override_me"
    tier = "override_me"               # TABLE_API | OCR_PAGE | VLM_PAGE

    def parse(self, ctx: PageCtx) -> list[Block]:
        raise NotImplementedError

    # ---- 所有 adapter 共用：把 API 返回的像素坐标换算回 PDF 点坐标 ----
    def to_pdf_bbox(self, px_bbox, ctx: PageCtx, dpi: int):
        sx = ctx.page_width / (ctx.page_width * dpi / 72.0)
        sy = ctx.page_height / (ctx.page_height * dpi / 72.0)
        x0, y0, x1, y1 = px_bbox
        return (round(x0 * sx, 1), round(y0 * sy, 1),
                round(x1 * sx, 1), round(y1 * sy, 1))


# ==========================================================================
# 1. 表格结构 API —— 区域级调用，最便宜，占预算 10%
# ==========================================================================

class TableApiAdapter(BaseAdapter):
    """输入：一个区域的裁剪图。输出：一个 type='table' 的 Block，html 必须带 rowspan/colspan。

    必须实现：
      - 合并单元格 → html 的 rowspan/colspan（丢了就等于没解析）
      - 每个单元格的 bbox 可选，但表格整体 bbox 必填
      - 若 ctx.hint 带 prev_page_table_header，把它作为表头拼到返回的表格前面
    验收：跑 tests 里的跨页续表用例，行列数一致且表头正确。
    """
    name = "table_api/v1"
    tier = "TABLE_API"

    def parse(self, ctx: PageCtx) -> list[Block]:
        raise NotImplementedError("填入公司表格结构 API 调用")


# ==========================================================================
# 2. OCR API —— 整页调用，占预算 9%（改掉 keep_figure_text 后应降到 ~1%）
# ==========================================================================

class OcrApiAdapter(BaseAdapter):
    """输入：整页图。输出：list[Block]，type 只允许 para / title / table / figure。

    必须实现：
      - 每个 block 必须带 bbox（换算回 PDF 点坐标），否则溯源断了
      - 不要让 OCR 结果覆盖已有的可信文本层 —— 只补齐缺失区域
    验收：对 baseline 里 9 个 OCR_PAGE 页，char_coverage 升到 ≥ 0.97。
    """
    name = "ocr_api/v1"
    tier = "OCR_PAGE"

    def parse(self, ctx: PageCtx) -> list[Block]:
        raise NotImplementedError("填入公司 OCR API 调用")


# ==========================================================================
# 3. VLM API —— 整页调用，最贵，必须压在预算内（目标 ≤ 3%）
# ==========================================================================

VLM_PROMPT = """把这一页转成结构化 JSON。严格要求：
1. 只输出页面上真实存在的文字，不要补全、不要润色、不要翻译。
2. 输出 blocks 数组，每项 {type, text, bbox, level?, html?}。
   type ∈ [title, para, list, table, figure, formula, caption, header, footer]。
3. 表格用 html 表示，必须保留 rowspan / colspan。
4. bbox 用相对坐标 [x0,y0,x1,y1]，取值 0~1。
5. 如果某块内容你无法确定，把它的 type 设为 "uncertain"，不要猜。
{hint_block}"""


class VlmApiAdapter(BaseAdapter):
    """输入：整页图（+ 可选跨页上下文）。输出：list[Block]。

    强制要求 —— 不做这两条就不要上线：
      - temperature = 0，并把 model 版本写进 Block.extractor，否则解析不可复现
      - **坐标回锚**：把返回文本逐段回锚到文本层/OCR 行；锚不上的文字判为幻觉，
        丢弃并把该页标记 needs_human。回锚率写进 Block.confidence。
    验收：对 baseline 里 1 个 VLM_PAGE 页，回锚率 ≥ 0.95 且闸门转 PASS。
    """
    name = "vlm_api/v1"
    tier = "VLM_PAGE"

    def parse(self, ctx: PageCtx) -> list[Block]:
        raise NotImplementedError("填入公司 VLM API 调用")

    @staticmethod
    def anchor_back(vlm_text: str, layer_lines: list[dict]) -> float:
        """返回可锚定字符占比。< 0.95 视为幻觉超标。"""
        pool = "".join(l["text"] for l in layer_lines)
        if not vlm_text:
            return 0.0
        return sum(1 for ch in vlm_text if ch in pool) / len(vlm_text)


# ==========================================================================
# 注册表：闸门返回的 escalate_to 直接映射到这里
# ==========================================================================

REGISTRY = {
    "TABLE_API_REGION": TableApiAdapter,
    "OCR_PAGE": OcrApiAdapter,
    "VLM_PAGE": VlmApiAdapter,
}


def escalate(escalate_to: str, ctx: PageCtx) -> list[Block]:
    cls = REGISTRY.get(escalate_to)
    if not cls:
        raise ValueError(f"未知升级目标 {escalate_to}")
    return cls().parse(ctx)
