# -*- coding: utf-8 -*-
"""Route A 的 Docling 版 adapter —— 验证"换后端不动路由和契约"这句话。

与 RouteANative 的唯一差别：文本单元来自 docling-parse 后端（真 Docling 组件，零 ML 模型），
其余几何规则、分类、后处理、闸门全部复用。

已知限制（本环境）：Docling 完整 PDF 路线要下载版面模型与 TableFormer 权重，
HuggingFace 被出网代理拒绝（403），所以表格区域仍由 PyMuPDF find_tables 提供。
docx / html / csv 路线不需要任何模型，可完整走 Docling —— 见 docling_docx 部分。
"""
from pathlib import Path

import docir_pipeline as P
from docling.backend.docling_parse_backend import DoclingParseDocumentBackend
from docling.datamodel.base_models import InputFormat
from docling.datamodel.document import InputDocument


class RouteADocling(P.RouteANative):
    name = "route_a/docling-parse+geometry"

    def __init__(self, pdf_path: str):
        self.pdf_path = Path(pdf_path)
        indoc = InputDocument(path_or_stream=self.pdf_path, format=InputFormat.PDF,
                              backend=DoclingParseDocumentBackend)
        self.be = DoclingParseDocumentBackend(indoc, self.pdf_path)

    def parse_page(self, doc, page_no, profile, lines=None):
        pg = self.be.load_page(page_no)
        lines = []
        for c in pg.get_text_cells():
            r = c.rect.to_bounding_box()
            txt = c.text.replace("\xa0", " ").strip()
            if not txt:
                continue
            lines.append({"text": txt,
                          "bbox": (round(r.l, 1), round(r.t, 1), round(r.r, 1), round(r.b, 1)),
                          "size": round(abs(r.b - r.t), 1)})   # 行高作字号代理
        return super().parse_page(doc, page_no, profile, lines=lines)


def run(path="/home/claude/demo/sop_hard.pdf"):
    import pymupdf
    doc = pymupdf.open(path)
    ir = P.DocIR(doc_id="SOP-QA-0417", source_uri=path)
    ad = RouteADocling(path)
    for pno in range(doc.page_count):
        prof = P.triage_page(doc, pno)
        blocks = ad.parse_page(doc, pno, prof)
        ir.blocks.extend(blocks)
        rep = P.gate_page(doc, pno, blocks, prof)
        rep["triage_reason"] = prof.reason
        rep["n_columns"] = prof.n_columns
        ir.page_reports.append(rep)
    logs = P.stitch_cross_page_tables(ir)
    for i, b in enumerate(sorted(ir.blocks, key=lambda x: (x.page, x.reading_order))):
        b.reading_order = i
    P.build_section_tree(ir)
    return ir, logs


if __name__ == "__main__":
    import json
    from dataclasses import asdict
    ir, logs = run()
    print("extractor:", ir.blocks[0].extractor)
    print("blocks:", len(ir.blocks), "| stitch:", logs)
    for r in ir.page_reports:
        print("gate:", json.dumps(r, ensure_ascii=False))
    for b in sorted(ir.blocks, key=lambda x: x.reading_order):
        print(f"  [p{b.page}/{b.reading_order:02d}] {b.type:8s} lvl={b.level} "
              f"parent={b.parent_id} :: {b.text[:34]!r}")
    with open("/home/claude/demo/docir_docling.json", "w") as f:
        json.dump({"page_reports": ir.page_reports,
                   "blocks": [asdict(b) for b in ir.blocks]}, f,
                  ensure_ascii=False, indent=2)
