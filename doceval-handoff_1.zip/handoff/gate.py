# -*- coding: utf-8 -*-
"""闸门 v2 —— 三个指标，外加一条"往哪升级"的路由。

v1 的问题（101 页实测）：只测"字没丢"，84% 的 title 误判它全部放行。
v2 加入分类断言，并且把失败原因映射到**最便宜的可用能力**，而不是一律叫 VLM：

  失败原因                        →  升级目标            成本量级
  ─────────────────────────────────────────────────────────────
  疑似无边框表格（区域级）        →  表格结构 / OCR API   低，且只发那一块
  字符覆盖率不足 / 乱码           →  OCR API（整页）      中
  版面判读整体失败 / 多项同时失败 →  VLM（整页）          高
  以上都没有                      →  PASS                 0
"""
import re
from collections import Counter

# ---------- 阈值：全部集中在这里，方便调 ----------
TH = {
    "char_coverage_min": 0.97,
    "garble_max": 0.02,
    "title_ratio_max": 0.30,      # 一页里 title 占比上限
    "title_min_n": 6,             # 且标题数达到这么多才算异常
    "numeric_line_min": 12,       # 触发"疑似无边框表格"的短数字行下限
    "numeric_col_min": 3,         # 且这些行至少落在 3 个 x 簇里
}

NUM_ONLY = re.compile(r"^[\d.,%×()\s+\-±/]+$")
PROSE = re.compile(r"[A-Za-z]{3,}\s+[A-Za-z]{3,}\s+[A-Za-z]{3,}")
GARBLE = re.compile(r"[�\x00-\x08\x0b\x0c\x0e-\x1f]")


# ==========================================================================
# 分类断言 —— 每条都便宜到可以对每一页跑
# ==========================================================================

def assert_classification(blocks) -> list[dict]:
    """返回违反的断言列表。每条带 code / 证据 / 建议升级目标。"""
    out = []
    body = [b for b in blocks if b.type not in ("header", "footer")]
    if not body:
        return out

    # A1：title 不能是纯数字或纯符号
    bad_t = [b for b in body if b.type == "title" and NUM_ONLY.match(b.text.strip())]
    if bad_t:
        out.append({"code": "A1_NUMERIC_TITLE", "n": len(bad_t),
                    "evidence": [b.text[:16] for b in bad_t[:4]],
                    "target": "TABLE_API",
                    "region": [round(min(b.bbox[0] for b in bad_t)),
                               round(min(b.bbox[1] for b in bad_t)),
                               round(max(b.bbox[2] for b in bad_t)),
                               round(max(b.bbox[3] for b in bad_t))]})

    # A2：formula 不能含连续三个英文单词（那是散文）
    bad_f = [b for b in body if b.type == "formula" and PROSE.search(b.text)]
    if bad_f:
        out.append({"code": "A2_PROSE_AS_FORMULA", "n": len(bad_f),
                    "evidence": [b.text[:28] for b in bad_f[:3]],
                    "target": "RULE_FIX"})     # 这条是自己规则的问题，不该花钱升级

    # A3：一页里 title 占比过高 = 版面判读整体失败。
    # 两个例外（101 页实测里全是误报）：目录页天然全是标题；新开一章的页标题也多。
    # 所以 A3 单独出现只记警告，不花钱升级；与其它断言同时出现才升级。
    is_toc = sum(1 for b in body if re.search(r"\.{4,}", b.text)) >= 5
    titles = [b for b in body if b.type == "title"]
    ratio = len(titles) / len(body)
    if not is_toc and ratio > TH["title_ratio_max"] and len(titles) >= TH["title_min_n"]:
        out.append({"code": "A3_TITLE_RATIO", "n": len(titles),
                    "evidence": [f"title {len(titles)}/{len(body)} = {ratio:.0%}"],
                    "target": "TABLE_API", "alone_is_warning": True,
                    "region": [round(min(b.bbox[0] for b in titles)),
                               round(min(b.bbox[1] for b in titles)),
                               round(max(b.bbox[2] for b in titles)),
                               round(max(b.bbox[3] for b in titles))]})

    # A4：短数字行成片出现却没检出表格 = 疑似无边框表格
    numeric = [b for b in body
               if b.type in ("title", "para") and len(b.text.strip()) <= 12
               and NUM_ONLY.match(b.text.strip())]
    has_table = any(b.type == "table" for b in blocks)
    if len(numeric) >= TH["numeric_line_min"] and not has_table:
        cols = len({round(b.bbox[0] / 40) for b in numeric})
        if cols >= TH["numeric_col_min"]:
            xs = [b.bbox[0] for b in numeric]; ys = [b.bbox[1] for b in numeric]
            xe = [b.bbox[2] for b in numeric]; ye = [b.bbox[3] for b in numeric]
            out.append({"code": "A4_BORDERLESS_TABLE", "n": len(numeric),
                        "evidence": [f"{len(numeric)} 个短数字块横跨 {cols} 个 x 簇"],
                        "target": "TABLE_API",
                        "region": [round(min(xs)), round(min(ys)),
                                   round(max(xe)), round(max(ye))]})
    return out


# ==========================================================================
# 闸门主体
# ==========================================================================

def gate_page(doc, page_no, blocks, profile, layer_lines_fn) -> dict:
    page = doc[page_no]
    layer_lines = layer_lines_fn(page)
    layer = re.sub(r"\s+", "", "".join(l["text"] for l in layer_lines))
    got = re.sub(r"\s+", "", "".join(b.text for b in blocks))

    cov = min(len(got) / max(len(layer), 1), 1.0)
    garble = len(GARBLE.findall(got)) / max(len(got), 1)

    tbl_valid = 1.0
    for b in blocks:
        if b.type == "table" and b.html:
            rows = re.findall(r"<tr>(.*?)</tr>", b.html, re.S)
            grid = [re.findall(r"<t[hd]>(.*?)</t[hd]>", r, re.S) for r in rows]
            if grid and len({len(r) for r in grid}) != 1:
                tbl_valid = 0.0

    viol = assert_classification(blocks)

    m = {"page": profile.page, "route": profile.route,
         "char_coverage": round(cov, 4), "garble_ratio": round(garble, 4),
         "table_validity": tbl_valid,
         "violations": [v["code"] for v in viol],
         "violation_detail": viol}

    # ---- 决定升级目标 ----
    # 原则一：归因合并。A4（无边框表格漏检）是根因时，A1/A3 是它的症状，
    #        不该因为"违反了 3 条断言"就跳到最贵的 VLM —— 先让表格 API 处理那一块。
    # 原则二：级联。表格 API 回来后重跑断言，仍不过才升 VLM（第二跳），
    #        所以下面统计的是**第一跳预算**，VLM 只由第二跳到达。
    codes = {v["code"] for v in viol}
    table_root_cause = "A4_BORDERLESS_TABLE" in codes
    if table_root_cause:
        codes -= {"A1_NUMERIC_TITLE", "A3_TITLE_RATIO"}

    # 原则三：只在"孤证"时降级为警告。A3 单独出现是误报高发区（目录页、新开章页）。
    effective = {c for c in codes}
    lone_warn = {v["code"] for v in viol if v.get("alone_is_warning")}
    if effective and effective <= lone_warn:
        effective = set()
        m["warning_only"] = sorted(lone_warn)

    targets = set()
    if cov < TH["char_coverage_min"] or garble > TH["garble_max"]:
        targets.add("OCR_PAGE")
    if tbl_valid < 1.0:
        targets.add("TABLE_API")
    for v in viol:
        if v["code"] in effective:
            targets.add(v["target"])

    m["root_cause"] = "A4_BORDERLESS_TABLE" if table_root_cause else (
        sorted(effective)[0] if effective else None)

    if not targets or targets == {"RULE_FIX"}:
        m["decision"] = "PASS_WITH_WARNING" if (targets or m.get("warning_only")) else "PASS"
        m["escalate_to"] = None
    elif "TABLE_API" in targets and "OCR_PAGE" not in targets:
        m["decision"] = "ESCALATE"
        m["escalate_to"] = "TABLE_API_REGION"  # 只发一个区域，最便宜
        m["regions"] = [v["region"] for v in viol if v.get("region")]
    elif "OCR_PAGE" in targets and "TABLE_API" not in targets:
        m["decision"] = "ESCALATE"
        m["escalate_to"] = "OCR_PAGE"
    else:
        # 文本层不可信 **且** 结构判读失败 —— 两个便宜手段都不足，这才值得 VLM
        m["decision"] = "ESCALATE"
        m["escalate_to"] = "VLM_PAGE"
    return m
