# -*- coding: utf-8 -*-
"""回归跑分：任何代码改动前后都跑这个，和 baseline_arxiv101.json 比。

用法:
    python run_eval.py testdata/arxiv            # 跑一个目录
    python run_eval.py testdata/arxiv --baseline baseline_arxiv101.json
"""
import argparse, collections, glob, json, os, sys, time

import pymupdf
import docir_pipeline as P
import gate


def run_dir(d):
    reps = []
    stats = collections.Counter()
    for f in sorted(glob.glob(os.path.join(d, "*.pdf"))):
        doc = pymupdf.open(f)
        ad = P.RouteANative()
        name = os.path.basename(f)
        t_p = t_g = 0.0
        for pno in range(doc.page_count):
            t = time.time(); prof = P.triage_page(doc, pno)
            blks = ad.parse_page(doc, pno, prof); t_p += time.time() - t
            t = time.time()
            r = gate.gate_page(doc, pno, blks, prof, P._layer_lines)
            t_g += time.time() - t
            r["file"] = name
            reps.append(r)
            stats[r["decision"]] += 1
            if r["escalate_to"]:
                stats[r["escalate_to"]] += 1
        n = doc.page_count
        print(f"{name:<24} {n:>3} 页  parse {t_p/n*1000:6.1f} ms/页  gate {t_g/n*1000:5.2f} ms/页")
    stats["total"] = len(reps)
    return reps, dict(stats)


def compare(actual, baseline_path):
    if not os.path.exists(baseline_path):
        print(f"\n(没有基线文件 {baseline_path}，跳过比对)")
        return 0
    exp = json.load(open(baseline_path))["expected"]
    keys = sorted(set(exp) | set(actual))
    print(f"\n{'项':<22}{'基线':>8}{'本次':>8}{'变化':>8}")
    regress = 0
    for k in keys:
        a, e = actual.get(k, 0), exp.get(k, 0)
        flag = ""
        # 判定"变差"：PASS 减少，或任何付费升级增加
        if k == "PASS" and a < e:
            flag = "  ← 变差"; regress += 1
        if k in ("OCR_PAGE", "VLM_PAGE", "TABLE_API_REGION") and a > e:
            flag = "  ← 成本上升"; regress += 1
        print(f"{k:<22}{e:>8}{a:>8}{a-e:>+8}{flag}")
    print("\n结论：" + ("通过" if regress == 0 else f"有 {regress} 项变差，不要合并"))
    return regress


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("path")
    ap.add_argument("--baseline", default="baseline_arxiv101.json")
    ap.add_argument("--dump", default="eval_reports.json")
    a = ap.parse_args()

    reps, stats = run_dir(a.path)
    print("\n=== 判定分布 ===")
    for k, v in sorted(stats.items()):
        print(f"  {k:<22}{v:>5}")
    json.dump(reps, open(a.dump, "w"), ensure_ascii=False, indent=1)
    sys.exit(1 if compare(stats, a.baseline) else 0)
